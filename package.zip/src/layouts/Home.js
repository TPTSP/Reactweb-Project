import React from "react";

import { getEmpData } from "../components/allData";

const Home = () => {
	return (
		<>
			<section className="pb-20 bg-gray-300 mt-0">
				<div className="container mx-auto px-4">
					<div className="flex flex-wrap">{getEmpData()}</div>
				</div>
			</section>
		</>
	);
};

export default Home;
